# Program No 1
# harga_awal = input ("Harga awal: ")
#
# harga  = int(harga_awal)
#
# if (harga > 50000):
#     diskon = (harga*27)/100
#     total_harga = harga - diskon
#
# elif (harga >= 30000):
#     diskon = (harga*22)/100
#     total_harga = harga - diskon
#
# else:
#     total_harga = harga
#
# # Prints in the console the variable as requested
# print ("The number you entered is: ", total_harga)

# Program no 2
# status = input("Apakah Bidikmisi : ")
# if (status == "BIDIKMISI"):
#     print("Anda mendapatkan golongan UKT 1")
# else :
#     gaji = input("Berapa gaji orang tua: ")
#     nilai_gaji = int(gaji)
#     if (nilai_gaji > 10000000):
#         print("Anda mendapatkan golongan UKT 5")
#     elif (nilai_gaji > 7000000):
#         print("Anda mendapatkan golongan UKT 4")
#     elif(nilai_gaji > 4000000):
#         print("Anda mendapatkan golongan UKT 3")
#     else :
#         print("Anda mendapatkan golongan UKT 2")

# Program 3
weight = int(input("weight: "))
height = int(input("height: "))
height_m = height/100

BMI = (weight/(height_m*height_m))
if (BMI >= 40):
    print("Class III Obesity")
elif(BMI >= 35):
    print("Class II Obesity")
elif(BMI >= 30):
    print("Class I Obesity")
elif(BMI >= 25):
    print("Overweight")
elif(BMI >= 18.5):
    print("Normal")
else :
    print("Below Normal Weight")
