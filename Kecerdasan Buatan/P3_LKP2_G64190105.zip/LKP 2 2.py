# agen.py
from agents import *
class MobilAutonom(Agent):
    def brake(self, people):
        print("Mobil: brake at {}.".format(self.location))
    def accelerate(self, no_people):
        print("Mobil: Accelerate at {}.".format( self.location))
    def reverse(self, Alley):
        print("Mobil: reverse  at {}.".format( self.location))
mobil = MobilAutonom()

# Environment.py
class people(thing):
    pass
class no_people(thing):
    pass
class alley(thing):
    pass

class Highway(Environment):
    def percept(self, agent):
        things = self.list_things_at(agent.location)
        print(things)
        return things
    def execute_action(self, agent, action):
        if action == "brake":
            aksi = self.list_things_at(agent.location, tclass=people)


        elif action == "accelerate":
            aksi = self.list_things_at(agent.location, tclass=no_people)

        elif action == "reverse":
            aksi = self.list_things_at(agent.location, tclass=alley)


# Program Utama
class MobilOtonom(Agent):
    location = 1
    def brake(self, people):
        # '''returns True upon success or False otherwise'''
        if people != none
            print("Mobil:  brake at {}.".format(self.location))
            location += 0
            return True
        return False
    def accelerate(self, no_people):
        # ''' returns True upon success or False otherwise'''
        if people == none:
            print("Mobil:  accelerate at {}.".format(self.location))
            location += 1
            return True
        return False
    def reverse(self, alley):
        # ''' returns True upon success or False otherwise'''
        if keadaan_alley == blind:
            print("Mobil:  reverse at {}.".format(self.location))
            location += -1
            return True
        return False
def program(percepts):
    '''Returns an action based on it's percepts'''
    for p in percepts:
        if isinstance(p, people):
            return 'brake'
        elif isinstance(p, no_people):
            return 'acceleration'
        elif isinstance(p, alley):
            return 'reverse'


