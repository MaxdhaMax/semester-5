def mahasiswa(uts, uas, prak, *to_aktif):
  nilai_dasar = ((uts * 30) / 100) + ((uas * 35) / 100) + ((prak * 30) / 100)

  nilai_aktif = 0
  i = 0
  for data in to_aktif:
    nilai_aktif += data
    i += 1
  nilai_aktif = ((nilai_aktif) * 5) / 100 / i

  nilai_total = nilai_dasar + float(nilai_aktif)
  print(nilai_total)
  return nilai_total


def mahasiswa_alih(uts, uas, prak, *to_aktif, **matrikulasi):
  nilai = ((uts * 25) / 100) + ((uas * 25) / 100) + ((prak * 20) / 100)

  nilai_aktif = 0
  i = 0

  for aktif in to_aktif:
    nilai_aktif += aktif
    i += 1

  nilai_aktif = ((nilai_aktif) * 5) / 100 / i
  nilai_total = nilai + float(nilai_aktif)

  for data in matrikulasi:
    nilai_total += ((matrikulasi[data] * 25) / 100)

  print(nilai_total)
  return nilai_total

def main():
  uts = int(input("Nilai UTS: "))
  uas = int(input("Nilai UAS: "))
  prak = int(input("Nilai praktikum: "))

  jumlah_aktif = int(input("Jumlah nilai keaktifan: "))
  aktif = 0
  aktif1 = 0
  aktif2 = 0

  if(jumlah_aktif == 1):
    aktif = int(input("Nilai Keaktifan 1: "))
  elif (jumlah_aktif == 2):
    aktif = int(input("Nilai Keaktifan 1: "))
    aktif1 = int(input("Nilai Keaktifan 2: "))
  elif (jumlah_aktif >= 3):
    aktif = int(input("Nilai Keaktifan 1: "))
    aktif1 = int(input("Nilai Keaktifan 2: "))
    aktif2 = int(input("Nilai Keaktifan 3: "))

  status = input("Apakah ada nilai Matrikulasi? Y / N ")
  if(status == "Y"):
    mahasiswa_alih(uts, uas, prak, aktif, aktif1, aktif2, matrik=int(input("Nilai Matrikulasi: ")))
  else:
    mahasiswa(uts, uas, prak, aktif, aktif1, aktif2)


main()

# 86, 78, 82, 80, 81, 81
# 85, 80, 86, 75, matrikulasi = 79
# 77, 65, 88, 75, 81, 80, matrikulasi = 82


